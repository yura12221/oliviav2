// components/Board.tsx
"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { TransformWrapper, TransformComponent } from "react-zoom-pan-pinch";

import { Dog, Kennel } from "./board/types";
import { useBoardData } from "./board/useBoardData";
import { useViewport, useBounds, useComputeFit } from "./board/useViewport";
import { useSearch } from "./board/useSearch";

import BoardToolbar from "./board/BoardToolbar";
import KennelCard from "./board/KennelCard";

import AddDogModal, { DogRecord } from "./AddDogModal";
import DogDetailsModal, { DogDetails } from "./DogDetailsModal";
import FilterListModal from "./FilterListModal";
import PrintPreviewModal, { PrintDog } from "./PrintPreviewModal";

export default function Board() {
  // data
  const { kennels, dogs, setDogs, loading, error, setError, load, dogsByCage, tryMoveDog } =
    useBoardData();

  // ui state
  const [editMode, setEditMode] = useState(false);
  const [dragDogId, setDragDogId] = useState<string | null>(null);
  const [hoverCage, setHoverCage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [selectedDogId, setSelectedDogId] = useState<string | null>(null);

  const [addOpen, setAddOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailsDog, setDetailsDog] = useState<DogDetails | null>(null);

  const [pickOpen, setPickOpen] = useState(false);
  const [printOpen, setPrintOpen] = useState(false);

  // === NEW: тренери (пам'ять у localStorage, без видалення старих фіч)
  const [trainers, setTrainers] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("trainers") || "[]" );
    } catch {
      return [];
    }
  });
  const [trainerName, setTrainerName] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem("trainers", JSON.stringify(trainers));
    } catch {}
  }, [trainers]);

  const addTrainer = (name: string) => {
    const t = name.trim();
    if (!t) return;
    setTrainers((prev) => (prev.includes(t) ? prev : [...prev, t]));
    setTrainerName(t);
  };
  // === /NEW

  const [picked, setPicked] = useState<Set<string>>(new Set());

  // viewport + transforms
  const { containerRef, vp } = useViewport();
  const bounds = useBounds(kennels);
  const twRef = useRef<any>(null);
  const computeFit = useComputeFit(vp, bounds);

  // search
  const { query, setQuery, q, matchDogIds, cagesWithMatches } = useSearch(dogs);

  // helpers
  const pickedDogs: PrintDog[] = useMemo(() => {
    const byId = new Map(dogs.map((d) => [d.id, d] as const));
    return Array.from(picked)
      .map((id) => byId.get(id))
      .filter((d): d is Dog => !!d)
      .map((d) => ({
        id: d.id,
        name: d.name,
        cage: d.cage,
        chip: d.chip ?? undefined,
        color: d.color ?? undefined,
        filters: d.filters ?? undefined,
        info: d.info ?? undefined,
      }));
  }, [picked, dogs]);

  const openDogDetails = (d: Dog) => {
    setDetailsDog({
      id: d.id,
      name: d.name,
      chip: d.chip ?? null,
      info: d.info ?? null,
      parents: d.parents ?? null,
      note: (d as any).note ?? null,
      color: d.color ?? null,
      second_color: (d as any).second_color ?? null,
      filters: Array.isArray(d.filters) ? (d.filters as string[]) : [],
      sovany: (d as any).sovany ?? false,
      cage: d.cage ?? null,
      position: (d as any).position ?? null,
      created_at: d.created_at,
      updated_at: d.updated_at,
    });
    setDetailsOpen(true);
  };

  const handleDogClick = (d: Dog, e: React.MouseEvent) => {
    e.stopPropagation();
    if (e.detail === 2) {
      openDogDetails(d);
      return;
    }
    if (editMode) setSelectedDogId((p) => (p === d.id ? null : d.id));
    else {
      const s = new Set(picked);
      s.has(d.id) ? s.delete(d.id) : s.add(d.id);
      setPicked(s);
    }
  };

  const onKennelDragOver = (ev: React.DragEvent, k: Kennel) => {
    if (!editMode) return;
    ev.preventDefault();
    ev.dataTransfer.dropEffect = "move";
    setHoverCage(k.cage);
  };
  const onKennelDrop = async (ev: React.DragEvent, target: Kennel) => {
    if (!editMode) return;
    ev.preventDefault();
    setHoverCage(null);
    const payload = ev.dataTransfer.getData("application/json");
    if (!payload) return;
    const { dogId, fromCage } = JSON.parse(payload) as {
      dogId: string;
      fromCage: string | null;
    };
    setSaving(true);
    await tryMoveDog(dogId, target.cage, fromCage, setDogs, load, setError);
    setSaving(false);
    setDragDogId(null);
  };

  const onDogDragStart = (e: React.DragEvent, d: Dog) => {
    if (!editMode || !d.id) return;
    setDragDogId(d.id);
    e.dataTransfer.setData(
      "application/json",
      JSON.stringify({ dogId: d.id, fromCage: d.cage || null })
    );
    e.dataTransfer.effectAllowed = "move";
    const g = document.createElement("div");
    g.style.position = "absolute";
    g.style.opacity = "0";
    document.body.appendChild(g);
    e.dataTransfer.setDragImage(g, 0, 0);
  };

  const resetSelection = () => {
    setPicked(new Set());
    setQuery("");
    setSelectedDogId(null);
    setHoverCage(null);
  };
  const toggleMode = () => {
    setEditMode((v) => !v);
    setSelectedDogId(null);
    setHoverCage(null);
  };

  return (
    <div className="board-page">
      <BoardToolbar
        zoomOut={() => twRef.current?.zoomOut(0.2, 200)}
        zoomIn={() => twRef.current?.zoomIn(0.2, 200)}
        fit={() => twRef.current?.setTransform(0, 0, computeFit(), 200)}
        reset100={() => twRef.current?.setTransform(0, 0, 1, 200)}
        query={query}
        setQuery={setQuery}
        editMode={editMode}
        toggleMode={toggleMode}
        resetSelection={resetSelection}
        openFilters={() => setPickOpen(true)}
        openPrint={() => setPrintOpen(true)}
        openAdd={() => setAddOpen(true)}
        pickedCount={picked.size}
        saving={saving}
      />

      <div className="board-content">
        <div
          ref={containerRef}
          className="board-viewport overflow-hidden border border-slate-800 rounded-lg"
          onDragOver={(e) => editMode && e.preventDefault()}
          onDrop={() => {
            setHoverCage(null);
            setDragDogId(null);
          }}
          onContextMenuCapture={(e) => {
            const t = e.target as HTMLElement | null;
            const chip = t?.closest<HTMLElement>(".dog-chip[data-id]");
            if (!chip) return;
            const d = dogs.find((x) => x.id === chip.dataset.id);
            if (!d) return;
            e.preventDefault();
            e.stopPropagation();
            openDogDetails(d);
          }}
        >
<TransformWrapper
  ref={twRef}
  minScale={0.3}
  maxScale={3}
  initialScale={computeFit()}
  centerOnInit
  limitToBounds={false}
  wheel={{ step: 0.12, smoothStep: 0.04, disabled: false }}   // ← ЛИШЕ ці ключі
  pinch={{ disabled: false }}
  panning={{ disabled: !!dragDogId, velocityDisabled: true }}
  doubleClick={{ disabled: true }}
>
            <TransformComponent>
              <div
                style={{
                  width: bounds.width,
                  height: bounds.height,
                  position: "relative",
                  background: "#0b1220",
                }}
              >
                {kennels.map((k) => {
                  const dogsHere = dogsByCage.get(k.cage) ?? [];
                  const kennelHasMatch = q ? cagesWithMatches.has(k.cage) : false;
                  const dimOthers = q.length > 0 && !kennelHasMatch;

                  return (
                    <KennelCard
                      key={k.cage}
                      k={k}
                      bounds={{ minX: bounds.minX, minY: bounds.minY }}
                      dogsHere={dogsHere}
                      dim={dimOthers}
                      editMode={editMode}
                      hoverCage={hoverCage}
                      selectedDogId={selectedDogId}
                      picked={picked}
                      matchDogIds={matchDogIds}
                      onMoveSelectedTo={async (cage) => {
                        if (!selectedDogId) return;
                        const moving = dogs.find((d) => d.id === selectedDogId);
                        if (!moving) return;
                        setSaving(true);
                        await tryMoveDog(
                          moving.id,
                          cage,
                          moving.cage || null,
                          setDogs,
                          load,
                          setError
                        );
                        setSaving(false);
                        setSelectedDogId(null);
                      }}
                      onKennelDragOver={onKennelDragOver}
                      onKennelDrop={onKennelDrop}
                      onDogClick={handleDogClick}
                      onDogContext={(d, e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        openDogDetails(d);
                      }}
                      onDogDragStart={onDogDragStart}
                      onDogDragEnd={() => {
                        setDragDogId(null);
                        setHoverCage(null);
                      }}
                      draggingId={dragDogId}
                    />
                  );
                })}
              </div>
            </TransformComponent>
          </TransformWrapper>
        </div>
      </div>

      {/* Modals */}
      <AddDogModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onCreated={(d: DogRecord) => setDogs((prev) => [d as any as Dog, ...prev])}
      />
      <DogDetailsModal
        open={detailsOpen}
        dog={detailsDog}
        onClose={() => setDetailsOpen(false)}
        onDeleted={(id) => {
          const s = new Set(picked);
          s.delete(id);
          setPicked(s);
          setSelectedDogId((p) => (p === id ? null : p));
          setDetailsDog(null);
          load();
        }}
        onUpdated={() => load()}
      />
      <FilterListModal
        open={pickOpen}
        onClose={() => setPickOpen(false)}
        onApply={(ids) => {
          const s = new Set(picked);
          ids.forEach((id) => s.add(id));
          setPicked(s);
        }}
      />
      <PrintPreviewModal
        open={printOpen}
        dogs={pickedDogs}
        trainerName={trainerName}
        setTrainerName={setTrainerName}
        trainers={trainers}
        onAddTrainer={addTrainer}
        onClose={() => setPrintOpen(false)}
        onRemove={(id) => {
          const s = new Set(picked);
          s.delete(id);
          setPicked(s);
        }}
      />
    </div>
  );
}
