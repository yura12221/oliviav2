
# Olívia Dog Center — Supabase + Next.js (App Router) Starter

Egyszerű, működő alap projekt a kenneltáblához: e-mail/jelszó belépés Supabase-szel,
sikeres belépés után megjelenik a **Kennel tábla** és a **Új kutya** űrlap.  
Kilépés után újra a belépő jelenik meg.

## Gyors indítás

1) **Klónozás / kicsomagolás**  
   Ezt a zipet bontsd ki egy mappába, majd:
   ```bash
   npm i
   npm run dev
   ```

2) **Supabase kulcsok**  
   Hozz létre `.env.local` fájlt a projekt gyökerében az alábbi tartalommal, és töltsd ki a saját adataiddal:
   ```ini
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_ANON_PUBLIC_KEY
   ```

3) **Adatbázis séma és RLS**  
   A Supabase projekted SQL részében futtasd le a `supabase.sql` tartalmát (másold be az SQL editorba és futtasd).  
   Ez létrehozza a táblákat: `profiles`, `kennels`, `dogs`, és beállítja az RLS szabályokat.

4) **Felhasználó + profil**  
   - Authentication → Users → Add user: add meg e-mailt és jelszót (azonnal aktív lesz).
   - Table Editor → `profiles` → Insert row: `id` = az előbb létrehozott auth user `id`-ja, `role` pl. `admin` vagy `editor`.

5) **Használat**  
   - Nyisd meg: `http://localhost:3000`  
   - Jelentkezz be (E-mail/Jelszó). Siker után eltűnik a belépő és látsz egy 4×4 kennel-táblát.  
   - `Új kutya` gombbal tudsz felvenni kutyát. A kutya bekerül a kiválasztott kennel-be.

## Parancsok

```bash
npm run dev     # fejlesztői mód
npm run build   # production build
npm start       # production futtatás
```

## Megjegyzések

- A felület magyar nyelvű.
- A jogosultságok (RLS) egyszerűsítettek: minden authentikált felhasználó olvashat/írhat a kutyákhoz és kennelekhez.
- A `profiles.role` mezőt felhasználhatod később finomabb jogosultságokhoz.
- A `supabase.sql` tartalmaz egy 4×4 kennelt (A1–D4) példa-adatokkal.
#   o l i v i a d o g  
 